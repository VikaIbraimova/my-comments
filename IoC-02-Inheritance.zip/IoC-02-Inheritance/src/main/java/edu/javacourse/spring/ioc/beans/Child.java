package edu.javacourse.spring.ioc.beans;

/**
 * Наследник класса Person
 */
public class Child extends Person {
    private Adult responsible;

    public Adult getResponsible() {
        return responsible;
    }

    public void setResponsible(Adult responsible) {
        this.responsible = responsible;
    }
}
