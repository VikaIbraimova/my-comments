package edu.javacourse.spring;

import edu.javacourse.spring.beans.Car7;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springExample.xml"})
public class Car7Test {

    @Autowired
    ApplicationContext context;

    /**
     * Перед запуском всех тестов для класса
     */
    @Test
    public void init() {
        /**
         * Проверяем есть ли объект уже
         * assertEquals(expected, result); // Если не равны - тест завален
         */
        System.out.println("===============================================");
        /**
         * Создаем объект тестируемого класса(создаем бин)
         */
        Car7 car7_3 = context.getBean("car7",Car7.class);
        /**
         * assertNotNull(new Money(10, "USD")); // Если null - тест завален
         */
        Assert.assertNotNull(car7_3);
        System.out.println("===============================================");
        System.out.println("Object car7_3:" + car7_3.toString());
        System.out.println("===============================================");

    }

    /**
     * Метод calls тестирует правильность счетчика вызовов методов класса.
     */
    @Test
    public void calls() {
        /**
         * assertEquals(expected, result); // Если не равны - тест завален
         */
        Assert.assertEquals(1,context.getBean("car7",Car7.class).getCalls());
    }
}
