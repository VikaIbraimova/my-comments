package edu.javacourse.spring.ioc;


import edu.javacourse.spring.ioc.beans.Car4;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SimpleBeanExample {

    //private static Logger log = LoggerFactory.getLogger(SimpleBeanExample.class);

    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"springExample.xml"});
        Car4 car4 = context.getBean("car4",Car4.class);
        System.out.println("Model car: " + car4.getModel());

        //log.debug("\n\n\n");

        //Car4 car = context.getBean("car", Car4.class);
        //log.debug("id: {}", car.getId());
        //log.debug("owner: {}", car.getOwner());
        //System.out.println("id: " + car.getId());
        //System.out.println("owner: " + car.getOwner());

    }
}
