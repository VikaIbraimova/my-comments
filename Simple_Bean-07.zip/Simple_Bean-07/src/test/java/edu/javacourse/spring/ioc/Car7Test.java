package edu.javacourse.spring.ioc;


import edu.javacourse.spring.ioc.beans.Car7;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Показываются два способа создания бина
 * и запуска теста на работоспособность конструктора без параметров класса Car6
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springExample.xml"})
public class Car7Test extends TestCase{

    @Autowired
    Car7 car7;

    /**
     * Данный тест проверяет:срабатывает ли после строки: Car5 car5;
     * конструктор без параметров:
     * Если закоментить конструктор без параметров в классе Car5,
     * потом вызвать метод assertNotNull, передав вновь созданный объект класса Car5
     * без параметров, то будет ошибка
     * @throws Exception
     */
    @Test
    public void testCar7() throws Exception {
         // Результат выражения отличен от Null?
         // Если нет, то тест провален(такой результат будет, если закоменчен конструктор без параметров к классе Car5)
         // Иначе тест пройден, если выражение car5 (ссылка не равна Null)
        //Проверяем, нулевая ссылка или нет?Сылка бде нулевая, если не отработает конструктор без параметров
        assertNotNull(car7);

        //car5.createCar5("BMW");
    }

    /**
     * Можно по другому тоже самое
     * /**
     * Будем использовать анотацию  @Autowired
     * и в springExample.xml пропишем <context:annotation-config />
     */
    @Autowired
    ApplicationContext context;

    @Test
    public void testCar6_2() throws Exception{
        Car7 car7_2 = context.getBean("car7",Car7.class);
        //car7_2.setModel("Infinity");
        /**
         * Тест не пройден
         */
        assertNotNull(car7_2);
        /**
         * Тест  пройден
         */
        //assertNull(car7_2);
    }
}
