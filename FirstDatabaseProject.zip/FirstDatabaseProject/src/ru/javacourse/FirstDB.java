package ru.javacourse;


        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.Statement;

public class FirstDB {

    public static void main(String[] args) throws Exception {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://localhost:5432/postgres";
        //String url = "jdbc:postgresql://localhost/postgres?postgres=postgres";
        String login = "postgres";
        String password = "postgres";
        Connection conn = DriverManager.getConnection(url, login, password);
        Statement stmt = conn.createStatement();
        //int i = stmt.executeUpdate("INSERT INTO st_group2 (group_id,groupname,curator,speciality)"
        //                        + "VALUES (2,'A2B2-C','Sidorov','Mathematika')");
        //----------------------------------
        //rsl = sel.executeQuery("INSERT INTO testtable (prim_key, main_geograph) VALUES ('kuku2', 'kuku2')");
        //int i = stmt.executeUpdate("INSERT INTO st_group3(groupname,curator,speciality)
        //        VALUES (2,'A2B2-C','Krasin','FIZIKA')");
        int i = stmt.executeUpdate("INSERT INTO st_group3 (group_id,groupname,curator,speciality) VALUES (2,'A2B2-C','Krasin','FIZIKA')");
        System.out.println("Result" + i);
    }
}
