package edu.javacourse.spring.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class SpringJDBCTemplateExample2 {

    private static final Logger log = LoggerFactory.getLogger(SpringJDBCTemplateExample2.class);

    public static void main(String[] args) throws SQLException {
        /**
         * 1.Создание контекста Spring
         */
        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"springContext.xml"});
        /**
         * Бин dataSource говорит Spring значения параметров для установки соежинения с БД PostgreSQL
         */
        DataSource dataSource = context.getBean("dataSource", DataSource.class);
        /**
         * Показываем имя класса, который мы получаем от Spring и будем пользовать
         */
        log.info("dataSource: {}", dataSource.getClass().getCanonicalName());
        /**
         * Получаем строку соединения
         */
        Connection connection = dataSource.getConnection();
        log.info("connection class: {}", connection.getClass().getCanonicalName());

        /**
         * Делаем какие то запросы к БД
         */
        /**
         * Дальше, когда нам connection не нужен мы вызываем метод close
         * Мы сами закрываем соединение
         */
        connection.close();
        /**
         * Потом можно снова создать соединение и снова пользоваться
         */
        connection = dataSource.getConnection();
        log.info("connection2 class: {}", connection.getClass().getCanonicalName());

        /**
         * Делаем какие то запросы к БД
         */
        connection.close();
    }
}