package edu.javacourse.spring.ioc;

//import edu.javacourse.spring.ioc.beans.Person;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.context.ApplicationContext;
        import org.springframework.context.support.ClassPathXmlApplicationContext;

        import java.util.Date;

public class ScopeExample {
    private static Logger log = LoggerFactory.getLogger(ScopeExample.class);

    public static void main(String[] args) throws InterruptedException {

        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"springContext.xml"});
        log.debug("\n\n\n");

        for (int i = 0; i < 10; i++) {
            Date currentDate = context.getBean("currentDate", Date.class);
            log.info("date: {}", currentDate);
            Thread.sleep(1000);
        }
    }
}