package ru.test3;

/**
 * Пример использования класса JUnitCore
 */

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;


public class TestMathFunc2 {

    private MathFunc math;

    @Before
    public void init() { math = new MathFunc(); }
    @After
    public void tearDown() { math = null; }

    /**
     * Метод calls тестирует правильность счетчика вызовов.
     */
    @Test
    public void calls() {
        /**
         * Проверяет, что два значения совпадают:
         */
        Assert.assertEquals(0, math.getCalls());

        math.factorial(1);
        Assert.assertEquals(1, math.getCalls());

        math.factorial(1);
        Assert.assertEquals(2, math.getCalls());
    }

    /**
     * Метод factorial проверяет правильность
     * вычисления факториала для некоторых стандартных значений
     */
    @Test
    public void factorial() {
        Assert.assertTrue(math.factorial(0) == 1);
        Assert.assertTrue(math.factorial(1) == 1);
        Assert.assertTrue(math.factorial(5) == 120);
    }

    /**
     * Метод factorialNegative проверяет,
     * что для отрицательных значений факотриала будет брошен IllegalArgumentException
     */
    @Test(expected = IllegalArgumentException.class)
    public void factorialNegative() {
        math.factorial(-1);
    }
    /**
     * Аннотация @Ignore говорит:
     * тест необхдимо пропустить.
     * Хотя можно просто удалить аннотацию @Test
     */
    @Ignore
    @Test
    public void todo() {
        Assert.assertTrue(math.plus(1, 1) == 3);
    }
    /**
     * В нашем современном мире IDE умеют находить
     * и просто запускать тесты в проекте.
     * Но что делать, если вы хотите запустить их вручную
     * с помощью программного кода. Для этого можно воспользоваться Runner'ом.
     * Бывают текстовый - junit.textui.TestRunner,
     * графические версии - junit.swingui.TestRunner, junit.awtui.TestRunner.
     * Но чуть более современный метод
     * - это использование класса JUnitCore.
     */
    public static void main(String[] args) throws Exception {
        JUnitCore runner = new JUnitCore();
        Result result = runner.run(TestMathFunc2.class);
        System.out.println("run tests: " + result.getRunCount());
        System.out.println("failed tests: " + result.getFailureCount());
        System.out.println("ignored tests: " + result.getIgnoreCount());
        System.out.println("success: " + result.wasSuccessful());
    }
    /**
     * Бывает такое, что для выполнения
     * каждого тестового сценария
     * вам необходим некоторый контекст,
     * например, заранее созданные экземпляры классов.
     * А после выполнения нужно освободить зарезервированные ресурсы.
     * В этом случае вам понадобятся аннтоации @Before и @After.
     * Метод, помеченный @Before будет выполняться перед каждым тестовым случаем,
     * а метод, помеченный @After - после каждого тестового случая.
     * Если же инициализацию и освобождение ресурсов нужно сделать всего один раз
     * - соответственно до и после всех тестов - то используйте пару аннотаций @BeforeClass и @AfterClass.
     */
}
