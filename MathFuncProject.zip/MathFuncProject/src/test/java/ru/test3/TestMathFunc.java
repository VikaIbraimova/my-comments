package ru.test3;

/**
 * Пример использования библиотеки(framework) JUnit4
 */
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class TestMathFunc {
    private MathFunc math;

    @Before
    public void init() { math = new MathFunc(); }
    @After
    public void tearDown() { math = null; }

    /**
     * Метод calls тестирует правильность счетчика вызовов.
     */
    @Test
    public void calls() {
        /**
         * Проверяет, что два значения совпадают:
         */
        Assert.assertEquals(0, math.getCalls());

        math.factorial(1);
        Assert.assertEquals(1, math.getCalls());

        math.factorial(1);
        Assert.assertEquals(2, math.getCalls());
    }

    /**
     * Метод factorial проверяет правильность
     * вычисления факториала для некоторых стандартных значений
     */
    @Test
    public void factorial() {
        Assert.assertTrue(math.factorial(0) == 1);
        Assert.assertTrue(math.factorial(1) == 1);
        Assert.assertTrue(math.factorial(5) == 120);
    }

    /**
     * Метод factorialNegative проверяет,
     * что для отрицательных значений факотриала будет брошен IllegalArgumentException
     */
    @Test(expected = IllegalArgumentException.class)
    public void factorialNegative() {
        math.factorial(-1);
    }

    /**
     * Аннотация @Ignore говорит:
     * тест необхдимо пропустить.
     * Хотя можно просто удалить аннотацию @Test
     */
    @Ignore
    @Test
    public void todo() {
        Assert.assertTrue(math.plus(1, 1) == 3);
    }
    /**
     * Бывает такое, что для выполнения
     * каждого тестового сценария
     * вам необходим некоторый контекст,
     * например, заранее созданные экземпляры классов.
     * А после выполнения нужно освободить зарезервированные ресурсы.
     * В этом случае вам понадобятся аннтоации @Before и @After.
     * Метод, помеченный @Before будет выполняться перед каждым тестовым случаем,
     * а метод, помеченный @After - после каждого тестового случая.
     * Если же инициализацию и освобождение ресурсов нужно сделать всего один раз
     * - соответственно до и после всех тестов - то используйте пару аннотаций @BeforeClass и @AfterClass.
     */
}