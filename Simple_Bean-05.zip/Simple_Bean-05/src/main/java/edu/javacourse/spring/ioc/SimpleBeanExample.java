package edu.javacourse.spring.ioc;


import edu.javacourse.spring.ioc.beans.Car5;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SimpleBeanExample {

    //private static Logger log = LoggerFactory.getLogger(SimpleBeanExample.class);

    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"springExample.xml"});
        Car5 car5 = context.getBean("car5",Car5.class);
        System.out.println("Model car: " + car5.getModel());

        //log.debug("\n\n\n");

        //Car5 car = context.getBean("car", Car5.class);
        //log.debug("id: {}", car.getId());
        //log.debug("owner: {}", car.getOwner());
        //System.out.println("id: " + car.getId());
        //System.out.println("owner: " + car.getOwner());

    }
}
