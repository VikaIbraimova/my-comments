package edu.javacourse.spring.test;


import edu.javacourse.spring.ioc.beans.Car5;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springExample.xml"})
public class Car5Test extends TestCase{

    @Autowired
    Car5 car5;

    /**
     * Данный тест проверяет:срабатывает ли после строки: Car5 car5;
     * конструктор без параметров:
     * Если закоментить конструктор без параметров в классе Car5,
     * потом вызвать метод assertNotNull, передав вновь созданный объект класса Car5
     * без параметров, то будет ошибка
     * @throws Exception
     */
    @Test
    public void testCar5() throws Exception {
        /**
         * Результат выражения отличен от Null?
         * Если нет, то тест провален(такой результат будет, если закоменчен конструктор без параметров к классе Car5)
         * Иначе тест пройден, если выражение car5 (ссылка не равна Null)
         * Проверяем, нулевая ссылка или нет?Сылка бде нулевая, если не отработает конструктор без параметров
         */
        assertNotNull(car5);

        //car5.createCar5("BMW");
    }
}
