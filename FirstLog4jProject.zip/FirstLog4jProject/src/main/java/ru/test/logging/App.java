package ru.test.logging;

//import java.util.logging.Logger;
//import org.appache.log4j.Logger;

//import java.util.logging.Logger;

import org.apache.log4j.Logger;

public class App {
    private static final Logger log = Logger.getLogger(App.class);
    public static void main(String[] args) {
                   log.info("Hello World!");
               }
       }

