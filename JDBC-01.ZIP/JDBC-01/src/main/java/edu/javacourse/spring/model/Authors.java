package edu.javacourse.spring.model;

/**
 * Created by Vika on 12.03.16.
 */
public class Authors {
    private Integer id;
    private String nameAuthors;

    public Authors() {
    }

    public Authors(Integer id, String nameAuthors) {
        this.id = id;
        this.nameAuthors = nameAuthors;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNameAuthors() {
        return nameAuthors;
    }

    public void setNameAuthors(String nameAuthors) {
        this.nameAuthors = nameAuthors;
    }

    @Override
    public String toString() {
        return "Authors{" +
                "id=" + id +
                ", nameAuthors='" + nameAuthors + '\'' +
                '}';
    }
}
